﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lesson_200_FixMe_2 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    Debug.Log("This code should be in start put it there");
    {
        
    }

    // Update is called once per frame
    void Update(Debug.Log("This code should be in update put it there);)
    {
        
    }
}
