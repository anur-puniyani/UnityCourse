﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lesson_200_FixMe_1 : MonoBehaviour
{
    GameObject.Instantiate(PrimitiveType.Sphere);//This code is not in the right place, put it in the right place
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
     GameObject.Instantiate(PrimitiveType.Cylinder);//This code is not in the right place, put it in the right place
}
